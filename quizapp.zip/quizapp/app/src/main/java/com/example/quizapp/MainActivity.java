package com.example.quizapp;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView totalQuestionTextView, questionTextView;
    Button ansA, ansB, ansC, ansD, submitAnswer;
    int score = 0;
    int totalQuestion;
    int currentQuestionIndex = 0;
    String selectedAnswer = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        totalQuestionTextView = findViewById(R.id.totalquestion);
        questionTextView = findViewById(R.id.question);
        ansA = findViewById(R.id.answerA);
        ansB = findViewById(R.id.answerB);
        ansC = findViewById(R.id.answerC);
        ansD = findViewById(R.id.answerD);
        submitAnswer = findViewById(R.id.submit);

        ansA.setOnClickListener(this);
        ansB.setOnClickListener(this);
        ansC.setOnClickListener(this);
        ansD.setOnClickListener(this);
        submitAnswer.setOnClickListener(this);

        // Initialize the quiz
        restartQuiz();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    public void onClick(View view) {
        // Reset all button colors
        ansA.setBackgroundColor(Color.WHITE);
        ansB.setBackgroundColor(Color.WHITE);
        ansC.setBackgroundColor(Color.WHITE);
        ansD.setBackgroundColor(Color.WHITE);

        Button clickedButton = (Button) view;

        if (clickedButton.getId() == R.id.submit) {
            if (currentQuestionIndex < totalQuestion) {
                QuestionAnswer.QuestionData currentQuestion = QuestionAnswer.randomizedQuestions.get(currentQuestionIndex);
                if (selectedAnswer.equals(currentQuestion.choices[currentQuestion.correctAnswerIndex])) {
                    score++;
                }
                currentQuestionIndex++;
                loadNewQuestion();
            }
        } else {
            // Highlight selected answer
            selectedAnswer = clickedButton.getText().toString();
            clickedButton.setBackgroundColor(Color.MAGENTA);
        }
    }

    void loadNewQuestion() {
        // Update total question display
        totalQuestionTextView.setText("Total questions: " + totalQuestion);

        if (currentQuestionIndex == totalQuestion) {
            finishQuiz();
            return;
        }

        QuestionAnswer.QuestionData currentQuestion = QuestionAnswer.randomizedQuestions.get(currentQuestionIndex);

        questionTextView.setText(currentQuestion.question);
        ansA.setText(currentQuestion.choices[0]);
        ansB.setText(currentQuestion.choices[1]);
        ansC.setText(currentQuestion.choices[2]);
        ansD.setText(currentQuestion.choices[3]);

        // Reset selected answer for new question
        selectedAnswer = "";
    }

    void finishQuiz() {

        String passStatus = (score > totalQuestion * 0.60) ? "Passed" : "Failed";

        new AlertDialog.Builder(this)
                .setTitle(passStatus)
                .setMessage("Score is " + score + " out of " + totalQuestion)
                .setPositiveButton("Restart", (dialogInterface, i) -> restartQuiz())
                .setCancelable(false)
                .show();
    }

    void restartQuiz() {
        score = 0;
        currentQuestionIndex = 0;

        // Re-randomize questions for new quiz
        QuestionAnswer.randomizedQuestions.clear();
        for (int i = 0; i < QuestionAnswer.questions.length; i++) {
            QuestionAnswer.randomizedQuestions.add(QuestionAnswer.createRandomizedQuestion(i));
        }

        // Update total question count
        totalQuestion = QuestionAnswer.randomizedQuestions.size();

        loadNewQuestion();
    }
}