package com.example.quizapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QuestionAnswer {
    public static String[] questions = {
            "Which company owns Android?",
            "Which language isn't a programming language?",
            "23 + 12?",
            "Which company owns Apple?",
            "Which company owns Facebook?"
    };

    public static String[][] choices = {
            {"Apple", "Google", "Facebook", "Tesla"},
            {"Java", "Python", "C++", "French"},
            {"20", "32", "35", "86"},
            {"Apple", "Google", "Facebook", "Tesla"},
            {"Apple", "Google", "Facebook", "Tesla"}
    };

    public static String[] correctAnswers = {
            "Google", "French", "35", "Apple", "Facebook"
    };

    // This will hold the randomized choices and the correct answer index for each question
    public static List<QuestionData> randomizedQuestions = new ArrayList<>();

    static {
        // Initialize the randomized questions
        for (int i = 0; i < questions.length; i++) {
            randomizedQuestions.add(createRandomizedQuestion(i));
        }
    }

    public static QuestionData createRandomizedQuestion(int questionIndex) {
        // Get the original choices and correct answer
        String[] originalChoices = choices[questionIndex];
        String correctAnswer = correctAnswers[questionIndex];

        // Create a list to shuffle
        List<String> choiceList = new ArrayList<>();
        for (String choice : originalChoices) {
            choiceList.add(choice);
        }

        // Shuffle the choices
        Collections.shuffle(choiceList);

        // Find the new index of the correct answer
        int correctIndex = choiceList.indexOf(correctAnswer);

        // Convert back to array
        String[] randomizedChoices = choiceList.toArray(new String[0]);

        return new QuestionData(
                questions[questionIndex],
                randomizedChoices,
                correctIndex
        );
    }

    public static class QuestionData {
        public final String question;
        public final String[] choices;
        public final int correctAnswerIndex;

        public QuestionData(String question, String[] choices, int correctAnswerIndex) {
            this.question = question;
            this.choices = choices;
            this.correctAnswerIndex = correctAnswerIndex;
        }
    }
}
