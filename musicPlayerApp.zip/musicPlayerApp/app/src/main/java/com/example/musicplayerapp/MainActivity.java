// MainActivity.java
package com.example.musicplayerapp; // Make sure this package name matches your project's package

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    // UI Elements
    private ImageView albumArtImageView;
    private TextView songTitleTextView;
    private TextView artistNameTextView;
    private SeekBar songProgressBar;
    private ImageView playPauseButton;
    private ImageView previousButton;
    private ImageView nextButton;
    private TextView currentTimeTextView;
    private TextView totalTimeTextView;

    // Music Player Logic
    private ArrayList<Map<String, String>> playlist;
    private int currentSongIndex = 0;
    private boolean isPlaying = false;
    private Handler handler = new Handler();
    private Runnable updateProgressRunnable;
    private int simulatedDuration = 30; // Simulate 30 seconds per song for progress bar
    private int currentProgress = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        albumArtImageView = findViewById(R.id.albumArtImageView);
        songTitleTextView = findViewById(R.id.songTitleTextView);
        artistNameTextView = findViewById(R.id.artistNameTextView);
        songProgressBar = findViewById(R.id.songProgressBar);
        playPauseButton = findViewById(R.id.playPauseButton);
        previousButton = findViewById(R.id.previousButton);
        nextButton = findViewById(R.id.nextButton);
        currentTimeTextView = findViewById(R.id.currentTimeTextView);
        totalTimeTextView = findViewById(R.id.totalTimeTextView);

        // Initialize playlist (simulated songs)
        playlist = new ArrayList<>();
        addSong("Summer Breeze", "Isabella Grace");
        addSong("City Lights", "The Urban Echoes");
        addSong("Mountain Trails", "Acoustic Journey");
        addSong("Rainy Day Blues", "Jazz Collective");
        addSong("Starlight Serenade", "Cosmic Harmonies");

        // Set up initial song display
        updateSongInfo();

        // Set up button click listeners
        playPauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePlayPause();
            }
        });

        previousButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playPreviousSong();
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playNextSong();
            }
        });

        // Set up SeekBar listener for simulated scrubbing
        songProgressBar.setMax(simulatedDuration); // Set max progress to simulated duration
        songProgressBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    currentProgress = progress;
                    updateTimeDisplay(currentProgress, simulatedDuration);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // Pause updates while user is scrubbing
                handler.removeCallbacks(updateProgressRunnable);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // Resume updates after scrubbing
                if (isPlaying) {
                    startProgressUpdate();
                }
            }
        });

        // Initialize the progress update runnable
        updateProgressRunnable = new Runnable() {
            @Override
            public void run() {
                if (isPlaying) {
                    currentProgress++;
                    if (currentProgress <= simulatedDuration) {
                        songProgressBar.setProgress(currentProgress);
                        updateTimeDisplay(currentProgress, simulatedDuration);
                        handler.postDelayed(this, 1000); // Update every second
                    } else {
                        // Song finished, play next
                        playNextSong();
                    }
                }
            }
        };
    }

    // Helper to add songs to the playlist
    private void addSong(String title, String artist) {
        Map<String, String> song = new HashMap<>();
        song.put("title", title);
        song.put("artist", artist);
        playlist.add(song);
    }

    // Update UI with current song information
    private void updateSongInfo() {
        if (playlist.isEmpty()) {
            songTitleTextView.setText("No Songs");
            artistNameTextView.setText("Add songs to playlist");
            albumArtImageView.setImageResource(R.drawable.ic_music_note); // Placeholder icon
            totalTimeTextView.setText("00:00");
            currentTimeTextView.setText("00:00");
            songProgressBar.setProgress(0);
            return;
        }

        Map<String, String> currentSong = playlist.get(currentSongIndex);
        songTitleTextView.setText(currentSong.get("title"));
        artistNameTextView.setText(currentSong.get("artist"));
        albumArtImageView.setImageResource(R.drawable.ic_album_art_placeholder); // Set a placeholder album art

        // Reset progress for new song
        currentProgress = 0;
        songProgressBar.setProgress(0);
        updateTimeDisplay(currentProgress, simulatedDuration);
        totalTimeTextView.setText(formatTime(simulatedDuration));
    }

    // Toggle play/pause state
    private void togglePlayPause() {
        if (isPlaying) {
            pauseSong();
        } else {
            playSong();
        }
    }

    // Simulate playing a song
    private void playSong() {
        isPlaying = true;
        playPauseButton.setImageResource(R.drawable.ic_pause); // Change to pause icon
        startProgressUpdate();
    }

    // Simulate pausing a song
    private void pauseSong() {
        isPlaying = false;
        playPauseButton.setImageResource(R.drawable.ic_play); // Change to play icon
        handler.removeCallbacks(updateProgressRunnable); // Stop progress updates
    }

    // Play the next song in the playlist
    private void playNextSong() {
        currentSongIndex = (currentSongIndex + 1) % playlist.size();
        updateSongInfo();
        if (isPlaying) { // If currently playing, continue playing next song
            startProgressUpdate();
        } else {
            // If paused, reset progress and update UI, but don't start playing
            pauseSong(); // Ensure play button is shown
        }
    }

    // Play the previous song in the playlist
    private void playPreviousSong() {
        currentSongIndex = (currentSongIndex - 1 + playlist.size()) % playlist.size();
        updateSongInfo();
        if (isPlaying) { // If currently playing, continue playing previous song
            startProgressUpdate();
        } else {
            // If paused, reset progress and update UI, but don't start playing
            pauseSong(); // Ensure play button is shown
        }
    }

    // Start updating the simulated progress bar
    private void startProgressUpdate() {
        handler.removeCallbacks(updateProgressRunnable); // Remove any existing callbacks
        handler.post(updateProgressRunnable); // Start new updates
    }

    // Update current and total time display
    private void updateTimeDisplay(int current, int total) {
        currentTimeTextView.setText(formatTime(current));
    }

    // Format time from seconds to MM:SS
    private String formatTime(int seconds) {
        int minutes = seconds / 60;
        int remainingSeconds = seconds % 60;
        return String.format("%02d:%02d", minutes, remainingSeconds);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove any pending callbacks to prevent memory leaks
        if (handler != null && updateProgressRunnable != null) {
            handler.removeCallbacks(updateProgressRunnable);
        }
    }
}
