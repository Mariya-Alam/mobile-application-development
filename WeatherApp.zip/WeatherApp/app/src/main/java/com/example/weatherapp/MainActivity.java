// MainActivity.java
package com.example.weatherapp; // Ensure this matches your project's package name

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Locale; 

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder; // For URL encoding

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "WeatherApp";

    // IMPORTANT: Replace with your actual OpenWeatherMap API Key
    // Get one for free from https://openweathermap.org/api
    private static final String API_KEY = "2b3bab635d928eb382ff1da73337031b"; // <-- REPLACE THIS!
    private static final String BASE_URL = "https://api.openweathermap.org/data/2.5/weather?";

    // UI Elements
    private EditText cityEditText;
    private Button getWeatherButton;
    private TextView cityNameTextView;
    private TextView temperatureTextView;
    private TextView conditionTextView;
    private ImageView weatherIconImageView; // Placeholder for now
    private ProgressBar loadingProgressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        cityEditText = findViewById(R.id.cityEditText);
        getWeatherButton = findViewById(R.id.getWeatherButton);
        cityNameTextView = findViewById(R.id.cityNameTextView);
        temperatureTextView = findViewById(R.id.temperatureTextView);
        conditionTextView = findViewById(R.id.conditionTextView);
        weatherIconImageView = findViewById(R.id.weatherIconImageView);
        loadingProgressBar = findViewById(R.id.loadingProgressBar);

        // Set initial state
        weatherIconImageView.setImageResource(R.drawable.ic_weather_placeholder); // Set a default icon

        // Set up button click listener
        getWeatherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city = cityEditText.getText().toString().trim();
                if (city.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a city name", Toast.LENGTH_SHORT).show();
                } else if (API_KEY.equals("YOUR_OPENWEATHERMAP_API_KEY")) {
                    Toast.makeText(MainActivity.this, "Please replace 'YOUR_OPENWEATHERMAP_API_KEY' with your actual API key in MainActivity.java", Toast.LENGTH_LONG).show();
                }
                else {
                    new FetchWeatherTask().execute(city);
                }
            }
        });
    }

    /**
     * AsyncTask to perform network operations in the background.
     * Params: String (city name)
     * Progress: Void
     * Result: String (JSON response or error message)
     */
    private class FetchWeatherTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            loadingProgressBar.setVisibility(View.VISIBLE); // Show loading indicator
            getWeatherButton.setEnabled(false); // Disable button during loading
            cityNameTextView.setText("");
            temperatureTextView.setText("");
            conditionTextView.setText("");
        }

        @Override
        protected String doInBackground(String... cities) {
            if (cities.length == 0) {
                return null;
            }
            String city = cities[0];
            HttpURLConnection urlConnection = null;
            BufferedReader reader = null;
            String weatherJsonString = null;

            try {
                // Construct the URL for the OpenWeatherMap API query
                // Use URLEncoder to handle spaces and special characters in city names
                String encodedCity = URLEncoder.encode(city, "UTF-8");
                URL url = new URL(BASE_URL + "q=" + encodedCity + "&appid=" + API_KEY + "&units=metric"); // units=metric for Celsius

                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.connect();

                // Read the input stream into a String
                int responseCode = urlConnection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    InputStreamReader inputStream = new InputStreamReader(urlConnection.getInputStream());
                    reader = new BufferedReader(inputStream);
                    StringBuilder buffer = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        buffer.append(line).append("\n");
                    }
                    weatherJsonString = buffer.toString();
                } else if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                    return "Error: City not found.";
                } else {
                    return "Error: " + urlConnection.getResponseMessage();
                }

            } catch (Exception e) {
                Log.e(TAG, "Error fetching weather data", e);
                return "Error: " + e.getMessage();
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (final Exception e) {
                        Log.e(TAG, "Error closing stream", e);
                    }
                }
            }
            return weatherJsonString;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            loadingProgressBar.setVisibility(View.GONE); // Hide loading indicator
            getWeatherButton.setEnabled(true); // Re-enable button

            if (result == null || result.startsWith("Error:")) {
                Toast.makeText(MainActivity.this, result != null ? result : "Unknown error occurred.", Toast.LENGTH_LONG).show();
                cityNameTextView.setText("N/A");
                temperatureTextView.setText("N/A");
                conditionTextView.setText("N/A");
                weatherIconImageView.setImageResource(R.drawable.ic_weather_placeholder); // Reset to default
                return;
            }

            try {
                JSONObject weatherJson = new JSONObject(result);

                // Check for "cod" field to see if it's an error from API (e.g., 404 for city not found)
                if (weatherJson.has("cod") && weatherJson.getString("cod").equals("404")) {
                    Toast.makeText(MainActivity.this, "City not found. Please try again.", Toast.LENGTH_LONG).show();
                    cityNameTextView.setText("N/A");
                    temperatureTextView.setText("N/A");
                    conditionTextView.setText("N/A");
                    weatherIconImageView.setImageResource(R.drawable.ic_weather_placeholder); // Reset to default
                    return;
                }

                // Extract city name
                String cityName = weatherJson.getString("name");

                // Extract temperature
                JSONObject main = weatherJson.getJSONObject("main");
                double temperature = main.getDouble("temp");

                // Extract weather condition description
                JSONArray weatherArray = weatherJson.getJSONArray("weather");
                JSONObject weatherObject = weatherArray.getJSONObject(0);
                String description = weatherObject.getString("description");

                // Update UI
                cityNameTextView.setText(cityName);
                temperatureTextView.setText(String.format(Locale.getDefault(), "%.1f°C", temperature));
                conditionTextView.setText(description.substring(0, 1).toUpperCase() + description.substring(1)); // Capitalize first letter

                // For a real app, you would map weatherObject.getString("icon") to specific drawable resources
                // For simplicity, we'll keep the placeholder icon or set a basic one based on condition.
                if (description.toLowerCase().contains("cloud")) {
                    weatherIconImageView.setImageResource(R.drawable.ic_weather_cloudy);
                } else if (description.toLowerCase().contains("rain") || description.toLowerCase().contains("drizzle")) {
                    weatherIconImageView.setImageResource(R.drawable.ic_weather_rainy);
                } else if (description.toLowerCase().contains("sun") || description.toLowerCase().contains("clear")) {
                    weatherIconImageView.setImageResource(R.drawable.ic_weather_sunny);
                } else {
                    weatherIconImageView.setImageResource(R.drawable.ic_weather_placeholder);
                }


            } catch (Exception e) {
                Log.e(TAG, "Error parsing JSON response", e);
                Toast.makeText(MainActivity.this, "Error processing weather data: " + e.getMessage(), Toast.LENGTH_LONG).show();
                cityNameTextView.setText("N/A");
                temperatureTextView.setText("N/A");
                conditionTextView.setText("N/A");
                weatherIconImageView.setImageResource(R.drawable.ic_weather_placeholder); // Reset to default
            }
        }
    }
}
