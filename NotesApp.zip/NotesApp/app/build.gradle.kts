plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.example.notesapp"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.notesapp"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {

    implementation(libs.appcompat)
    // Firebase platform
    implementation(platform("com.google.firebase:firebase-bom:32.8.1")) // Use the latest BOM version
// Firebase Authentication
    implementation("com.google.firebase:firebase-auth")
// Cloud Firestore
    implementation("com.google.firebase:firebase-firestore")
    implementation ("ndroidx.recyclerview:recyclerview:1.3.2")
// CardView
    implementation ("androidx.cardview:cardview:1.0.0")
// Material Design (for FloatingActionButton)
    implementation ("com.google.android.material:material:1.12.0") // Use the latest Material Design version
    implementation(libs.material)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
}