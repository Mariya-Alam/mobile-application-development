// NoteAdapter.java
package com.example.notesapp; // Ensure this matches your project's package name

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private List<Note> noteList;
    private Context context;
    private OnNoteListener onNoteListener;

    public NoteAdapter(List<Note> noteList, Context context, OnNoteListener onNoteListener) {
        this.noteList = noteList;
        this.context = context;
        this.onNoteListener = onNoteListener;
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.note_item, parent, false);
        return new NoteViewHolder(view, onNoteListener);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note currentNote = noteList.get(position);
        holder.titleTextView.setText(currentNote.getTitle());
        // Truncate content for display in list
        String contentPreview = currentNote.getContent();
        if (contentPreview.length() > 100) { // Show first 100 characters
            contentPreview = contentPreview.substring(0, 100) + "...";
        }
        holder.contentTextView.setText(contentPreview);

        // Format timestamp
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault());
        String formattedDate = sdf.format(new Date(currentNote.getTimestamp()));
        holder.timestampTextView.setText(formattedDate);
    }

    @Override
    public int getItemCount() {
        return noteList.size();
    }

    public static class NoteViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView titleTextView;
        TextView contentTextView;
        TextView timestampTextView;
        ImageView deleteButton;
        OnNoteListener onNoteListener;

        public NoteViewHolder(@NonNull View itemView, OnNoteListener onNoteListener) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.noteTitleTextView);
            contentTextView = itemView.findViewById(R.id.noteContentTextView);
            timestampTextView = itemView.findViewById(R.id.noteTimestampTextView);
            deleteButton = itemView.findViewById(R.id.deleteNoteButton);
            this.onNoteListener = onNoteListener;

            itemView.setOnClickListener(this); // For editing note
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (onNoteListener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            onNoteListener.onDeleteClick(position);
                        }
                    }
                }
            });
        }

        @Override
        public void onClick(View v) {
            if (onNoteListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    onNoteListener.onNoteClick(position);
                }
            }
        }
    }

    public interface OnNoteListener {
        void onNoteClick(int position);
        void onDeleteClick(int position);
    }
}
