// AddEditNoteActivity.java
package com.example.notesapp; // Ensure this matches your project's package name

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AddEditNoteActivity extends AppCompatActivity {

    private EditText editTextTitle;
    private EditText editTextContent;
    private Button buttonSaveNote;

    private String noteId; // To store the ID if editing an existing note

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_note);

        editTextTitle = findViewById(R.id.editTextNoteTitle);
        editTextContent = findViewById(R.id.editTextNoteContent);
        buttonSaveNote = findViewById(R.id.buttonSaveNote);

        // Check if we are editing an existing note
        Intent intent = getIntent();
        if (intent.hasExtra("noteId")) {
            setTitle("Edit Note");
            noteId = intent.getStringExtra("noteId");
            editTextTitle.setText(intent.getStringExtra("noteTitle"));
            editTextContent.setText(intent.getStringExtra("noteContent"));
        } else {
            setTitle("Add Note");
        }

        buttonSaveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveNote();
            }
        });
    }

    /**
     * Gathers data from EditText fields and sends it back to MainActivity.
     */
    private void saveNote() {
        String title = editTextTitle.getText().toString().trim();
        String content = editTextContent.getText().toString().trim();

        if (title.isEmpty()) {
            Toast.makeText(this, "Title cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent data = new Intent();
        data.putExtra("noteTitle", title);
        data.putExtra("noteContent", content);
        if (noteId != null) {
            data.putExtra("noteId", noteId); // Pass the ID back if editing
        }

        setResult(RESULT_OK, data);
        finish(); // Close this activity
    }
}
