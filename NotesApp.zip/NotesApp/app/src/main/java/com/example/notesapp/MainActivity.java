// MainActivity.java
package com.example.notesapp; // Ensure this matches your project's package name

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp; // Import FirebaseApp
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.ListenerRegistration; // Import for onSnapshot listener

import java.util.ArrayList;
import java.util.Collections; // For sorting
import java.util.Comparator; // For sorting
import java.util.List;
import java.util.UUID; // For anonymous user ID if auth fails completely

public class MainActivity extends AppCompatActivity implements NoteAdapter.OnNoteListener {

    private static final String TAG = "NotesApp";
    private static final int ADD_NOTE_REQUEST = 1;
    private static final int EDIT_NOTE_REQUEST = 2;

    // A placeholder for the app ID in Firestore paths.
    // In a real multi-user environment, this might be dynamically set or part of a larger system.
    // For a simple personal notes app, it can be a fixed string.
    private static final String APP_ID_PLACEHOLDER = "my_notes_app_id";

    // UI Elements
    private RecyclerView notesRecyclerView;
    private FloatingActionButton addNoteFab;
    private TextView userIdTextView;
    private ProgressBar loadingProgressBar;

    // Firebase
    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private CollectionReference notesCollection;
    private String userId; // This will store the Firebase User ID (UID)
    private ListenerRegistration notesListenerRegistration; // To manage real-time listener

    // Adapter for RecyclerView
    private NoteAdapter noteAdapter;
    private List<Note> noteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        notesRecyclerView = findViewById(R.id.notesRecyclerView);
        addNoteFab = findViewById(R.id.addNoteFab);
        userIdTextView = findViewById(R.id.userIdTextView);
        loadingProgressBar = findViewById(R.id.loadingProgressBar);

        // Initialize Firebase
        initializeFirebase();

        // Set up RecyclerView
        notesRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        noteList = new ArrayList<>();
        noteAdapter = new NoteAdapter(noteList, this, this); // Pass this activity as listener
        notesRecyclerView.setAdapter(noteAdapter);

        // Set up Add Note Floating Action Button
        addNoteFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddEditNoteActivity.class);
                startActivityForResult(intent, ADD_NOTE_REQUEST);
            }
        });
    }

    /**
     * Initializes Firebase services (Auth and Firestore) and authenticates the user anonymously.
     * This method assumes 'google-services.json' is present in the project's app module.
     */
    private void initializeFirebase() {
        try {
            // Initialize Firebase App. This typically uses google-services.json.
            // Ensure you have downloaded and placed google-services.json in your app/ directory.
            FirebaseApp.initializeApp(this);

            auth = FirebaseAuth.getInstance();
            db = FirebaseFirestore.getInstance();

            // Sign in anonymously. This creates a temporary user if one isn't already signed in.
            auth.signInAnonymously()
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Log.d(TAG, "signInAnonymously:success");
                                FirebaseUser user = auth.getCurrentUser();
                                if (user != null) {
                                    userId = user.getUid();
                                    setupFirestore();
                                } else {
                                    Log.e(TAG, "signInAnonymously: User is null after successful sign-in.");
                                    // Fallback: Generate a random UUID if FirebaseUser is unexpectedly null
                                    userId = UUID.randomUUID().toString();
                                    setupFirestore();
                                }
                            } else {
                                Log.w(TAG, "signInAnonymously:failure", task.getException());
                                Toast.makeText(MainActivity.this, "Authentication failed: " + task.getException().getMessage(),
                                        Toast.LENGTH_SHORT).show();
                                // Fallback: Generate a random UUID if anonymous sign-in fails
                                userId = UUID.randomUUID().toString();
                                setupFirestore();
                            }
                        }
                    });

        } catch (Exception e) {
            Log.e(TAG, "Error initializing Firebase: " + e.getMessage());
            Toast.makeText(this, "Error initializing Firebase: " + e.getMessage() + ". Make sure google-services.json is in your app/ directory.", Toast.LENGTH_LONG).show();
            // Fallback: Generate a random UUID if Firebase initialization fails entirely
            userId = UUID.randomUUID().toString();
            setupFirestore(); // Try to proceed with a dummy userId for collection path
        }
    }

    /**
     * Sets up Firestore collection reference and starts listening for notes.
     * This is called AFTER successful authentication and userId is available.
     */
    private void setupFirestore() {
        if (userId == null || userId.isEmpty()) {
            Log.e(TAG, "Firestore setup called before userId is available.");
            Toast.makeText(this, "User ID not available for Firestore setup. Notes might not save.", Toast.LENGTH_LONG).show();
            return;
        }

        // Display userId on UI. This is the Firebase UID.
        userIdTextView.setText("User ID: " + userId);

        // Define the collection path for private user data in Firestore.
        // Format: /artifacts/{APP_ID_PLACEHOLDER}/users/{userId}/notes
        // This structure is designed to align with typical Firestore security rules for private data.
        String collectionPath = String.format("/artifacts/%s/users/%s/notes", APP_ID_PLACEHOLDER, userId);
        notesCollection = db.collection(collectionPath);
        Log.d(TAG, "Firestore collection path: " + collectionPath);

        // Start listening for real-time updates to notes
        startListeningForNotes();
    }

    /**
     * Attaches a real-time listener to the notes collection.
     */
    private void startListeningForNotes() {
        loadingProgressBar.setVisibility(View.VISIBLE); // Show loading indicator
        notesListenerRegistration = notesCollection.addSnapshotListener(new com.google.firebase.firestore.EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@NonNull QuerySnapshot snapshots,
                                @NonNull com.google.firebase.firestore.FirebaseFirestoreException e) {
                loadingProgressBar.setVisibility(View.GONE); // Hide loading indicator

                if (e != null) {
                    Log.w(TAG, "Listen failed.", e);
                    Toast.makeText(MainActivity.this, "Failed to load notes: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    return;
                }

                noteList.clear(); // Clear existing notes
                for (QueryDocumentSnapshot doc : snapshots) {
                    // Convert Firestore document to Note object
                    String id = doc.getId();
                    String title = doc.getString("title");
                    String content = doc.getString("content");
                    // Firestore's getLong returns Long, which can be null. Handle it.
                    long timestamp = doc.getLong("timestamp") != null ? doc.getLong("timestamp") : 0;

                    if (title != null && content != null) {
                        noteList.add(new Note(id, title, content, timestamp));
                    }
                }

                // Sort notes by timestamp (most recent first)
                Collections.sort(noteList, new Comparator<Note>() {
                    @Override
                    public int compare(Note n1, Note n2) {
                        return Long.compare(n2.getTimestamp(), n1.getTimestamp()); // Descending order (newest first)
                    }
                });

                noteAdapter.notifyDataSetChanged(); // Notify adapter of data change
                Log.d(TAG, "Notes updated. Total: " + noteList.size());
                if (noteList.isEmpty()) {
                    Toast.makeText(MainActivity.this, "No notes yet. Tap '+' to add one!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Detach listener when activity is stopped to prevent memory leaks
        if (notesListenerRegistration != null) {
            notesListenerRegistration.remove();
            Log.d(TAG, "Firestore listener detached.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            String noteId = data.getStringExtra("noteId");
            String noteTitle = data.getStringExtra("noteTitle");
            String noteContent = data.getStringExtra("noteContent");

            if (noteTitle == null || noteTitle.isEmpty()) {
                Toast.makeText(this, "Note title cannot be empty.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Create a Map for the note data to be sent to Firestore
            java.util.Map<String, Object> noteData = new java.util.HashMap<>();
            noteData.put("title", noteTitle);
            noteData.put("content", noteContent);
            noteData.put("timestamp", System.currentTimeMillis()); // Always update timestamp on save/edit

            if (requestCode == ADD_NOTE_REQUEST) {
                // Add new note to Firestore
                notesCollection.add(noteData)
                        .addOnSuccessListener(documentReference -> {
                            Toast.makeText(MainActivity.this, "Note added!", Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "Note added with ID: " + documentReference.getId());
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(MainActivity.this, "Error adding note: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.e(TAG, "Error adding note", e);
                        });
            } else if (requestCode == EDIT_NOTE_REQUEST && noteId != null) {
                // Update existing note in Firestore
                // Use .set() to replace the document, or .update() for partial updates.
                // .set() is simpler here as we're sending all fields.
                notesCollection.document(noteId).set(noteData)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(MainActivity.this, "Note updated!", Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "Note updated with ID: " + noteId);
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(MainActivity.this, "Error updating note: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            Log.e(TAG, "Error updating note", e);
                        });
            }
        }
    }

    @Override
    public void onNoteClick(int position) {
        // Handle note click for editing
        Note clickedNote = noteList.get(position);
        Intent intent = new Intent(MainActivity.this, AddEditNoteActivity.class);
        intent.putExtra("noteId", clickedNote.getId());
        intent.putExtra("noteTitle", clickedNote.getTitle());
        intent.putExtra("noteContent", clickedNote.getContent());
        startActivityForResult(intent, EDIT_NOTE_REQUEST);
    }

    @Override
    public void onDeleteClick(int position) {
        // Handle note deletion
        Note noteToDelete = noteList.get(position);
        if (noteToDelete.getId() != null) {
            notesCollection.document(noteToDelete.getId()).delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(MainActivity.this, "Note deleted!", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, "Note deleted with ID: " + noteToDelete.getId());
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(MainActivity.this, "Error deleting note: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        Log.e(TAG, "Error deleting note", e);
                    });
        }
    }
}
