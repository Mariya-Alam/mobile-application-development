// MainActivity.java
package com.example.figmaapp; // Make sure this package name matches your project's package

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private ImageView mainPhotoImageView;
    private TextView currentFilterTextView; // To show which filter is active

    // Filter ImageViews (acting as buttons)
    private ImageView originalFilterButton;
    private ImageView grayscaleFilterButton;
    private ImageView sepiaFilterButton;
    private ImageView brightFilterButton;

    private ImageView saveButton;

    // Keep track of the current filter applied (for demonstration)
    private String currentFilter = "Original";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        mainPhotoImageView = findViewById(R.id.mainPhotoImageView);
        currentFilterTextView = findViewById(R.id.currentFilterTextView);

        originalFilterButton = findViewById(R.id.originalFilterButton);
        grayscaleFilterButton = findViewById(R.id.grayscaleFilterButton);
        sepiaFilterButton = findViewById(R.id.sepiaFilterButton);
        brightFilterButton = findViewById(R.id.brightFilterButton);

        saveButton = findViewById(R.id.saveButton);

        // Set initial state
        mainPhotoImageView.setImageResource(R.drawable.ic_main_photo_placeholder);
        currentFilterTextView.setText("Current Filter: Original");

        // Set up click listeners for filter buttons
        originalFilterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyFilter("Original");
            }
        });

        grayscaleFilterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyFilter("Grayscale");
            }
        });

        sepiaFilterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyFilter("Sepia");
            }
        });

        brightFilterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                applyFilter("Bright");
            }
        });

        // Set up click listener for save button
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Image saved with " + currentFilter + " filter!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Simulates applying a filter by changing the main image view's drawable.
     * In a real app, this would involve actual image processing.
     * @param filterName The name of the filter to apply.
     */
    private void applyFilter(String filterName) {
        currentFilter = filterName;
        currentFilterTextView.setText("Current Filter: " + filterName);

        switch (filterName) {
            case "Original":
                mainPhotoImageView.setImageResource(R.drawable.ic_main_photo_placeholder);
                break;
            default:
                mainPhotoImageView.setImageResource(R.drawable.ic_main_photo_placeholder);
                break;
        }
        Toast.makeText(this, filterName + " filter applied!", Toast.LENGTH_SHORT).show();
    }
}
