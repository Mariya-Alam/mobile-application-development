// MainActivity.java
package com.example.braintestapp; // Make sure this package name matches your project's package

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView questionTextView;
    private Button answer1Button, answer2Button, answer3Button, answer4Button;
    private TextView scoreTextView;
    private TextView timerTextView;
    private TextView resultTextView;

    private int score = 0;
    private int correctAnswer;
    private int totalQuestions = 0;
    private int timeLeft = 30; // seconds
    private Handler handler;
    private Runnable runnable;
    private boolean gameActive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        questionTextView = findViewById(R.id.questionTextView);
        answer1Button = findViewById(R.id.answer1Button);
        answer2Button = findViewById(R.id.answer2Button);
        answer3Button = findViewById(R.id.answer3Button);
        answer4Button = findViewById(R.id.answer4Button);
        scoreTextView = findViewById(R.id.scoreTextView);
        timerTextView = findViewById(R.id.timerTextView);
        resultTextView = findViewById(R.id.resultTextView);

        // Set up click listeners for answer buttons
        answer1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(Integer.parseInt(answer1Button.getText().toString()));
            }
        });

        answer2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(Integer.parseInt(answer2Button.getText().toString()));
            }
        });

        answer3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(Integer.parseInt(answer3Button.getText().toString()));
            }
        });

        answer4Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(Integer.parseInt(answer4Button.getText().toString()));
            }
        });

        // Initialize handler for timer
        handler = new Handler();

        // Start the game
        startGame();
    }

    private void startGame() {
        score = 0;
        totalQuestions = 0;
        timeLeft = 30;
        scoreTextView.setText("Score: 0");
        resultTextView.setText("");
        gameActive = true;
        generateQuestion();
        startTimer();
    }

    private void generateQuestion() {
        if (!gameActive) return;

        Random random = new Random();
        int a = random.nextInt(20) + 1; // Numbers from 1 to 20
        int b = random.nextInt(20) + 1;
        int operator = random.nextInt(3); // 0 for +, 1 for -, 2 for *

        String question;
        switch (operator) {
            case 0:
                question = a + " + " + b + " = ?";
                correctAnswer = a + b;
                break;
            case 1:
                // Ensure positive result for subtraction
                if (a < b) {
                    int temp = a;
                    a = b;
                    b = temp;
                }
                question = a + " - " + b + " = ?";
                correctAnswer = a - b;
                break;
            case 2:
                // Keep multiplication numbers smaller for simpler calculations
                a = random.nextInt(10) + 1;
                b = random.nextInt(10) + 1;
                question = a + " * " + b + " = ?";
                correctAnswer = a * b;
                break;
            default:
                question = "";
                correctAnswer = 0;
                break;
        }

        questionTextView.setText(question);
        totalQuestions++;

        // Generate incorrect answers
        int[] answers = new int[4];
        answers[random.nextInt(4)] = correctAnswer; // Place correct answer randomly

        for (int i = 0; i < 4; i++) {
            if (answers[i] == 0) { // If not the correct answer slot
                int incorrectAnswer;
                do {
                    incorrectAnswer = correctAnswer + (random.nextInt(10) - 5); // +/- 5 from correct answer
                    if (incorrectAnswer < 0) incorrectAnswer = 0; // Ensure non-negative answers
                } while (incorrectAnswer == correctAnswer); // Ensure it's not the correct answer
                answers[i] = incorrectAnswer;
            }
        }

        // Set button texts
        answer1Button.setText(String.valueOf(answers[0]));
        answer2Button.setText(String.valueOf(answers[1]));
        answer3Button.setText(String.valueOf(answers[2]));
        answer4Button.setText(String.valueOf(answers[3]));
    }

    private void checkAnswer(int selectedAnswer) {
        if (!gameActive) return;

        if (selectedAnswer == correctAnswer) {
            score++;
            resultTextView.setText("Correct!");
        } else {
            resultTextView.setText("Wrong! Correct was: " + correctAnswer);
        }
        scoreTextView.setText("Score: " + score);

        // Generate next question after a short delay to show result
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                generateQuestion();
                resultTextView.setText(""); // Clear result text
            }
        }, 500); // 0.5 second delay
    }

    private void startTimer() {
        runnable = new Runnable() {
            @Override
            public void run() {
                timeLeft--;
                timerTextView.setText("Time: " + timeLeft + "s");

                if (timeLeft > 0 && gameActive) {
                    handler.postDelayed(this, 1000); // Run every second
                } else {
                    endGame();
                }
            }
        };
        handler.postDelayed(runnable, 1000);
    }

    private void endGame() {
        gameActive = false;
        handler.removeCallbacks(runnable); // Stop the timer
        questionTextView.setText("Game Over!");
        resultTextView.setText("Final Score: " + score + " out of " + (totalQuestions -1) + " questions answered.");
        // Disable buttons
        answer1Button.setEnabled(false);
        answer2Button.setEnabled(false);
        answer3Button.setEnabled(false);
        answer4Button.setEnabled(false);

        // Optionally, add a "Play Again" button or dialog here
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove any pending callbacks to prevent memory leaks
        if (handler != null && runnable != null) {
            handler.removeCallbacks(runnable);
        }
    }
}
